import './Modal.css';

function Modal({ tipo, item, onClose, onSave }) {
  if (tipo === 'detalhe' && item) {
    return (
      <div className="modal-overlay" onClick={onClose}>
        <div className="modal" onClick={(e) => e.stopPropagation()}>
          <button className="modal__close" onClick={onClose}>✕</button>
          <div className="modal__icon">{getIcon(item.categoria)}</div>
          <h2 className="modal__title">{item.titulo}</h2>
          <p className="modal__desc">{item.descricao}</p>
          <div className="modal__info">
            <div className="modal__info-row">
              <span className="modal__label">Status</span>
              <span className="modal__value">{item.status}</span>
            </div>
            <div className="modal__info-row">
              <span className="modal__label">Categoria</span>
              <span className="modal__value">{item.categoria}</span>
            </div>
            {item.horario && (
              <div className="modal__info-row">
                <span className="modal__label">Horário</span>
                <span className="modal__value">{item.horario}</span>
              </div>
            )}
          </div>
          <button className="modal__btn" onClick={onClose}>Fechar</button>
        </div>
      </div>
    );
  }

  if (tipo === 'novo') {
    return (
      <div className="modal-overlay" onClick={onClose}>
        <div className="modal modal--form" onClick={(e) => e.stopPropagation()}>
          <button className="modal__close" onClick={onClose}>✕</button>
          <h2 className="modal__title">Novo Card</h2>
          <NovoCardForm onSave={onSave} onClose={onClose} />
        </div>
      </div>
    );
  }

  return null;
}

function NovoCardForm({ onSave, onClose }) {
  const handleSubmit = (e) => {
    e.preventDefault();
    const fd = new FormData(e.target);
    const novo = {
      id: Date.now(),
      titulo: fd.get('titulo'),
      descricao: fd.get('descricao'),
      status: fd.get('status'),
      categoria: fd.get('categoria'),
      horario: fd.get('horario'),
    };
    onSave(novo);
  };

  return (
    <form className="modal__form" onSubmit={handleSubmit}>
      <label className="modal__field">
        <span>Título *</span>
        <input name="titulo" required placeholder="Ex: Sala 07" />
      </label>
      <label className="modal__field">
        <span>Descrição *</span>
        <textarea name="descricao" required placeholder="Breve descrição..." rows={3} />
      </label>
      <label className="modal__field">
        <span>Status *</span>
        <select name="status" required>
          <option value="Disponível">Disponível</option>
          <option value="Em andamento">Em andamento</option>
          <option value="Finalizado">Finalizado</option>
          <option value="Pendente">Pendente</option>
        </select>
      </label>
      <label className="modal__field">
        <span>Categoria *</span>
        <select name="categoria" required>
          <option value="Laboratório">Laboratório</option>
          <option value="Aula Teórica">Aula Teórica</option>
          <option value="Avaliação">Avaliação</option>
          <option value="Reunião">Reunião</option>
          <option value="Workshop">Workshop</option>
          <option value="Projeto">Projeto</option>
          <option value="Estudo">Estudo</option>
        </select>
      </label>
      <label className="modal__field">
        <span>Horário</span>
        <input name="horario" placeholder="Ex: 08:00 - 10:00" />
      </label>
      <div className="modal__form-actions">
        <button type="button" className="modal__btn modal__btn--cancel" onClick={onClose}>Cancelar</button>
        <button type="submit" className="modal__btn">Adicionar</button>
      </div>
    </form>
  );
}

function getIcon(categoria) {
  const icons = {
    'Laboratório': '🧪', 'Aula Teórica': '📖', 'Avaliação': '📝',
    'Reunião': '🤝', 'Workshop': '🛠️', 'Projeto': '🚀', 'Estudo': '💡',
  };
  return icons[categoria] || '📌';
}

export default Modal;
