import './Filtro.css';

const STATUS_LIST = ['Todos', 'Disponível', 'Em andamento', 'Finalizado', 'Pendente'];

function Filtro({ filtroAtivo, onFiltroChange, contadores, busca, onBuscaChange, onAddCard }) {
  return (
    <div className="filtro">
      <div className="filtro__top">
        <div className="filtro__search-wrapper">
          <span className="filtro__search-icon">🔍</span>
          <input
            className="filtro__search"
            type="text"
            placeholder="Buscar por nome..."
            value={busca}
            onChange={(e) => onBuscaChange(e.target.value)}
          />
        </div>
        <button className="filtro__add-btn" onClick={onAddCard}>
          + Novo Card
        </button>
      </div>

      <div className="filtro__botoes">
        {STATUS_LIST.map((status) => (
          <button
            key={status}
            className={`filtro__btn ${filtroAtivo === status ? 'filtro__btn--ativo' : ''}`}
            onClick={() => onFiltroChange(status)}
          >
            {status}
            {contadores[status] !== undefined && (
              <span className="filtro__badge">{contadores[status]}</span>
            )}
          </button>
        ))}
      </div>
    </div>
  );
}

export default Filtro;
