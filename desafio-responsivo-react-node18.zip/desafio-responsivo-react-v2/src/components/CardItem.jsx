import { useState } from 'react';
import './CardItem.css';

const STATUS_COLORS = {
  'Disponível': 'status--disponivel',
  'Em andamento': 'status--andamento',
  'Finalizado': 'status--finalizado',
  'Pendente': 'status--pendente',
};

const CATEGORIA_ICONS = {
  'Laboratório': '🧪',
  'Aula Teórica': '📖',
  'Avaliação': '📝',
  'Reunião': '🤝',
  'Workshop': '🛠️',
  'Projeto': '🚀',
  'Estudo': '💡',
};

function CardItem({ item, onAction }) {
  const [hovered, setHovered] = useState(false);

  const statusClass = STATUS_COLORS[item.status] || '';
  const icon = CATEGORIA_ICONS[item.categoria] || '📌';

  return (
    <div
      className={`card ${hovered ? 'card--hovered' : ''}`}
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
    >
      <div className="card__header">
        <span className="card__icon">{icon}</span>
        <span className={`card__status ${statusClass}`}>{item.status}</span>
      </div>

      <h3 className="card__title">{item.titulo}</h3>
      <p className="card__desc">{item.descricao}</p>

      <div className="card__meta">
        <span className="card__categoria">{item.categoria}</span>
        {item.horario && (
          <span className="card__horario">🕐 {item.horario}</span>
        )}
      </div>

      <button
        className="card__btn"
        onClick={() => onAction && onAction(item)}
      >
        Ver detalhes
      </button>
    </div>
  );
}

export default CardItem;
