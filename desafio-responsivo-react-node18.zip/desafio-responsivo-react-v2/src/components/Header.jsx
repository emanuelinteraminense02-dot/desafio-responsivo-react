import './Header.css';

function Header({ darkMode, toggleDarkMode }) {
  return (
    <header className="header">
      <div className="header__brand">
        <div className="header__logo">
          <span className="header__logo-icon">📋</span>
        </div>
        <div className="header__titles">
          <h1 className="header__title">Painel de Organização</h1>
          <p className="header__subtitle">Controle de atividades da turma</p>
        </div>
      </div>

      <nav className="header__nav">
        <a href="#" className="header__nav-link">Início</a>
        <a href="#" className="header__nav-link">Relatórios</a>
        <a href="#" className="header__nav-link">Configurações</a>
      </nav>

      <button
        className="header__theme-btn"
        onClick={toggleDarkMode}
        title="Alternar modo claro/escuro"
      >
        {darkMode ? '☀️' : '🌙'}
      </button>
    </header>
  );
}

export default Header;
