import { useState, useMemo } from 'react';
import Header from './components/Header';
import CardItem from './components/CardItem';
import Filtro from './components/Filtro';
import Modal from './components/Modal';
import './App.css';

const DADOS_INICIAIS = [
  { id: 1, titulo: 'Sala 01', descricao: 'Disponível para reservas. Capacidade para 30 alunos com projetor e ar-condicionado.', status: 'Disponível', categoria: 'Laboratório', horario: '08:00 - 12:00' },
  { id: 2, titulo: 'Sala 02', descricao: 'Aula de Algoritmos em andamento com a turma do 2º semestre.', status: 'Em andamento', categoria: 'Aula Teórica', horario: '14:00 - 16:00' },
  { id: 3, titulo: 'Avaliação P2', descricao: 'Prova de Estruturas de Dados marcada para o final do mês.', status: 'Pendente', categoria: 'Avaliação', horario: '10:00 - 12:00' },
  { id: 4, titulo: 'Reunião Pedagógica', descricao: 'Reunião do colegiado para revisão do plano de ensino do semestre.', status: 'Finalizado', categoria: 'Reunião', horario: '09:00 - 10:30' },
  { id: 5, titulo: 'Workshop React', descricao: 'Introdução ao React com hooks modernos e boas práticas de desenvolvimento.', status: 'Em andamento', categoria: 'Workshop', horario: '13:00 - 17:00' },
  { id: 6, titulo: 'Projeto Final', descricao: 'Entrega do projeto final da disciplina de Engenharia de Software.', status: 'Pendente', categoria: 'Projeto', horario: '—' },
  { id: 7, titulo: 'Estudo Dirigido', descricao: 'Material de apoio para revisão de banco de dados relacional.', status: 'Disponível', categoria: 'Estudo', horario: 'Livre' },
  { id: 8, titulo: 'Sala 03 — TI', descricao: 'Laboratório de informática com 20 computadores disponíveis.', status: 'Disponível', categoria: 'Laboratório', horario: '07:00 - 22:00' },
  { id: 9, titulo: 'Sprint Review', descricao: 'Apresentação das sprints do projeto integrador para os professores.', status: 'Finalizado', categoria: 'Projeto', horario: '11:00 - 12:00' },
];

function App() {
  const [darkMode, setDarkMode] = useState(false);
  const [filtro, setFiltro] = useState('Todos');
  const [busca, setBusca] = useState('');
  const [cards, setCards] = useState(DADOS_INICIAIS);
  const [modal, setModal] = useState(null);

  const contadores = useMemo(() => {
    const c = { Todos: cards.length };
    cards.forEach((card) => {
      c[card.status] = (c[card.status] || 0) + 1;
    });
    return c;
  }, [cards]);

  const cardsFiltrados = useMemo(() => {
    return cards.filter((card) => {
      const passaFiltro = filtro === 'Todos' || card.status === filtro;
      const passaBusca = busca.trim() === '' || card.titulo.toLowerCase().includes(busca.toLowerCase());
      return passaFiltro && passaBusca;
    });
  }, [cards, filtro, busca]);

  const handleAddCard = (novoCard) => {
    setCards((prev) => [novoCard, ...prev]);
    setModal(null);
  };

  return (
    <div className="app" data-theme={darkMode ? 'dark' : 'light'}>
      <Header darkMode={darkMode} toggleDarkMode={() => setDarkMode((d) => !d)} />

      <main className="main">
        <section className="main__hero">
          <h2 className="main__heading">Painel de Atividades</h2>
          <p className="main__sub">
            {cardsFiltrados.length} {cardsFiltrados.length === 1 ? 'item encontrado' : 'itens encontrados'}
          </p>
        </section>

        <div className="main__counters">
          {['Disponível', 'Em andamento', 'Pendente', 'Finalizado'].map((s) => (
            <div key={s} className={`counter counter--${s.replace(/ /g, '-').toLowerCase()}`}>
              <span className="counter__num">{contadores[s] || 0}</span>
              <span className="counter__label">{s}</span>
            </div>
          ))}
        </div>

        <Filtro
          filtroAtivo={filtro}
          onFiltroChange={setFiltro}
          contadores={contadores}
          busca={busca}
          onBuscaChange={setBusca}
          onAddCard={() => setModal({ tipo: 'novo' })}
        />

        {cardsFiltrados.length === 0 ? (
          <div className="empty-state">
            <span className="empty-state__icon">🔎</span>
            <p>Nenhum item encontrado para <strong>"{busca || filtro}"</strong></p>
          </div>
        ) : (
          <div className="cards">
            {cardsFiltrados.map((card) => (
              <CardItem
                key={card.id}
                item={card}
                onAction={(item) => setModal({ tipo: 'detalhe', item })}
              />
            ))}
          </div>
        )}
      </main>

      <footer className="footer">
        <p>Painel de Organização — React + Vite · {new Date().getFullYear()}</p>
      </footer>

      {modal && (
        <Modal
          tipo={modal.tipo}
          item={modal.item}
          onClose={() => setModal(null)}
          onSave={handleAddCard}
        />
      )}
    </div>
  );
}

export default App;
